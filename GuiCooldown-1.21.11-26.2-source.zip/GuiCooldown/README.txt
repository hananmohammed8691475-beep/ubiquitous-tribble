GuiCooldown - Paper 1.21.11 and 26.2
Build:  mvn clean package   (Java 21+)
Output: target/GuiCooldown-1.21.11-26.2.jar -> put in /plugins
Config: plugins/GuiCooldown/config.yml -> cooldown-ticks (default 3). Restart to apply.
