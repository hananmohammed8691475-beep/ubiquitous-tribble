package me.wwqkaka.guicooldown;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class GuiCooldown extends JavaPlugin implements Listener {

    private int cooldownTicks;
    private final Map<UUID, Integer> lastOpen = new HashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        cooldownTicks = Math.max(1, getConfig().getInt("cooldown-ticks", 3));
        Bukkit.getPluginManager().registerEvents(this, this);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onOpen(InventoryOpenEvent e) {
        if (!(e.getPlayer() instanceof Player p)) return;

        int now = Bukkit.getCurrentTick();
        Integer last = lastOpen.get(p.getUniqueId());

        if (last != null && now - last < cooldownTicks) {
            e.setCancelled(true);
            return;
        }
        lastOpen.put(p.getUniqueId(), now);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        lastOpen.remove(e.getPlayer().getUniqueId());
    }
}
